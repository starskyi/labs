</div>
		<div id="footer">
			<center>Copyright&nbsp;@&nbsp;2018&nbsp;by&nbsp;<a href="http://gv7.me">c0ny1</a></center>
		</div>
		<div class="mask"></div>
		<div class="dialog">
		    <div class="dialog-title">提&nbsp;示<a href="javascript:void(0)" class="close" title="关闭">关闭</a></div>
		    <div class="dialog-content"></div>
		</div>		
</body>
<script type="text/javascript" src="<?php echo $site_root;?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $site_root;?>/js/prism.js"></script>
<script type="text/javascript" src="<?php echo $site_root;?>/js/index.js"></script>
</html>
