<?php

if($_GET['action'] == 'get_prompt'){
    echo '本pass在客户端使用js对不合法图片进行检查！';
}

?>