<?php
$passid = $_COOKIE['pass'];
$style = 'class="a_is_selected"';
?>
<div id="menu">
	<ul>
		<li><a <?php if($passid == '01'){echo $style;}?> href="<?php echo $site_root;?>/Pass-01/index.php">Pass-01</a></li>
		<li><a <?php if($passid == '02'){echo $style;}?> href="<?php echo $site_root;?>/Pass-02/index.php">Pass-02</a></li>
		<li><a <?php if($passid == '03'){echo $style;}?> href="<?php echo $site_root;?>/Pass-03/index.php">Pass-03</a></li>
		<li><a <?php if($passid == '04'){echo $style;}?> href="<?php echo $site_root;?>/Pass-04/index.php">Pass-04</a></li>
		<li><a <?php if($passid == '05'){echo $style;}?> href="<?php echo $site_root;?>/Pass-05/index.php">Pass-05</a></li>
		<li><a <?php if($passid == '06'){echo $style;}?> href="<?php echo $site_root;?>/Pass-06/index.php">Pass-06</a></li>
		<li><a <?php if($passid == '07'){echo $style;}?> href="<?php echo $site_root;?>/Pass-07/index.php">Pass-07</a></li>
		<li><a <?php if($passid == '08'){echo $style;}?> href="<?php echo $site_root;?>/Pass-08/index.php">Pass-08</a></li>
		<li><a <?php if($passid == '09'){echo $style;}?> href="<?php echo $site_root;?>/Pass-09/index.php">Pass-09</a></li>
		<li><a <?php if($passid == '10'){echo $style;}?> href="<?php echo $site_root;?>/Pass-10/index.php">Pass-10</a></li>
		<li><a <?php if($passid == '11'){echo $style;}?> href="<?php echo $site_root;?>/Pass-11/index.php">Pass-11</a></li>
		<li><a <?php if($passid == '12'){echo $style;}?> href="<?php echo $site_root;?>/Pass-12/index.php">Pass-12</a></li>
		<li><a <?php if($passid == '13'){echo $style;}?> href="<?php echo $site_root;?>/Pass-13/index.php">Pass-13</a></li>
		<li><a <?php if($passid == '14'){echo $style;}?> href="<?php echo $site_root;?>/Pass-14/index.php">Pass-14</a></li>
		<li><a <?php if($passid == '15'){echo $style;}?> href="<?php echo $site_root;?>/Pass-15/index.php">Pass-15</a></li>
		<li><a <?php if($passid == '16'){echo $style;}?> href="<?php echo $site_root;?>/Pass-16/index.php">Pass-16</a></li>
		<li><a <?php if($passid == '17'){echo $style;}?> href="<?php echo $site_root;?>/Pass-17/index.php">Pass-17</a></li>
		<li><a <?php if($passid == '18'){echo $style;}?> href="<?php echo $site_root;?>/Pass-18/index.php">Pass-18</a></li>
		<li><a <?php if($passid == '19'){echo $style;}?> href="<?php echo $site_root;?>/Pass-19/index.php">Pass-19</a></li>
	</ul>
</div>